// get information from page 'code'
document.querySelector('.code').classList.add('clearnone');
setTimeout(()=>{
    document.querySelector('.code').classList.add('scale');
},1);