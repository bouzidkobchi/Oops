// add class 'show' to show div upload
setTimeout(()=>{
    document.querySelector('.uploadphoto').classList.add('show');
},10);
