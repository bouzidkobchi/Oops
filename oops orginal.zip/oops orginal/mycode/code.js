// get information from page 'code'
document.querySelector('.code').classList.add('clearnone');
let a = document.querySelector('a');
setTimeout(()=>{
    document.querySelector('.code').classList.add('scale');
},1);
let code = 000000; // code from server it send to user to restor account
let codeuser = document.querySelectorAll('input[type="number"]'); // when user enter code and we check it with code from server 
let newcode;
// get all value from all inputs
codeuser[codeuser.length-1].addEventListener('keyup',(e)=>{
if(e.keyCode !== 8){
    let codearr =[];
    codeuser.forEach((input)=>{
        codearr.push(input.value);
    });
      newcode = parseInt(codearr.join(''));
      // check of valid value between code and code user
    if(code === newcode){
        // click at join now !
        document.querySelector('.changeCode').click();
    }else{
        codeuser.forEach((input)=>{
            input.value = '';
        });
        codeuser[0].focus();
        document.querySelector('error').classList.add('showWarning');
        setTimeout(()=>{
            document.querySelector('error').classList.remove('showWarning');
        },1500);
    }
}
});
codeuser[0].focus(); // default value focus on first input
for(let i=0;i<=codeuser.length-1;i++){
    codeuser[i].addEventListener('keyup',(e)=>{
        if(e.keyCode !== 189 && e.keyCode !== 69 && e.keyCode !== 187){
                    if(i!==5 && codeuser[i].value !== ''){
            codeuser[i+1].focus();
        }
            if(e.keyCode === 8 ){
           if(i>0 && i<=5){
            codeuser[i-1].focus();
           codeuser[i-1].value = '';
           }
        }
        }else{
            codeuser[i].value = '';
        }
    });
}